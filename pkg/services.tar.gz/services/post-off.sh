#!/bin/bash

kill -9 $(pgrep -f "post.py")
