#!/bin/bash

kill -9 $(pgrep -f "login.py")
