#!/bin/bash

kill -9 $(pgrep -f "media.py")
